# Överlämning: automatisk nollpunkt för LowRider V4

Datum 2026-11-04. Svara Adam på svenska, kort, ett steg i taget, och förklara fackord. Adam läser sista meningarna: lägg frågan sist. Inga onödiga prov.

## Läge
Koncept B2: servofälld touchprob. Fullständig bakgrund: `dokument/konceptutvardering.md` (export, original: https://claude.ai/artifact/8KpAQ7kQZWCSr8SRZ5obtD).
Provarm v0 är ritad, krockkontrollerad digitalt och skivad. Den är **inte utskriven eller provad**.
Nästa steg: Adam printar, monterar och provar armen. Testet av hemkörningens upprepbarhet (prov 1) är struket på Adams uttryckliga önskan.

## Beslut från Adam
- Blank aluminium och akryl måste kunna mätas; lasern är struken.
- M1 = 16,3 mm: hylsmutterns undersida under dammskoplattans undersida.
- Utstick högst 30 mm. Längsta KWB är 53,6 mm totalt och antas sitta 24 mm i chucken (Adam tror det, ej mätt).
- Tjockt material prioriteras (gravsten 50 mm har frästs).
- Kablarna vid Core-ytan är förberedda för touchplatta. Mätklocka och touchplatta finns inte.

## Koordinater (fräsramen M, mm)
x bort från Core, y längs balken, z upp, fräsaxel x=y=0. Samma origo som V1E:s Makita-STL.
Core.stl till M: `x_M = x-193,7`, `y_M = z-92,5`, `z_M = -(y-169,17)+94,75`. Härlett ur skruvhålen.
Core-yta x=-15. M5-hål y=±43,95, z=64,25/125,25. Core-ände y=73. Hylsmutter z=14,7.
Led och servoaxel (10,5; 48; 35). Spets nedfälld z=-20,3. Uppfälld ca y=75, z=84 vid ca 153°.

## Status för uppgifter
**Beräknat i CAD:** arm och fäste krockar inte med Core, verktygsfäste, sko eller kjol; arm minst 8,5 mm mot skanningen. Bussningarna ligger an mot verktygsfästet med avsikt.
**Mätt i skanningen:** Core-ände y 73,75 (CAD 73,0), Core-yta x -17 till -18 (CAD -15), hylsmutter z 14-16. Skon: median 1,5 mm mot CAD, skala 0,9945.
**Antaget:** utstick ca 19 mm i gränsen ca 57 mm material; servo 40×20×41 mm och hål 49,5×10 mm (butiksannons, standard); nedre örat bara vilande.
**Okänt:** servots svängvinkel (armen kräver ca 153°), sätets upprepbarhet (M3-skalle i printat V-spår), servoarmens form, fjäderretur och alla livslängdsmål.
**Kända brister:** arm uppfälld ca 2 mm utanför Core-änden; skanningen kan ligga ca 6 mm/6° fel; automatisk inpassning av hela Core gav bara 31 %, så läget bygger på hålen.

## Inköp och montering
2 st M5×45 är nya. Led: M5×16–18 + nyloc (huvud bakom plattan, mutter framför armen; längre skruv tar i servoarmen, M5×30 måste kapas till ca 17 mm). Övrigt: 6 st M3×10 (probspets, sätesskruv, 2 till servoöron, gummibandsfäste, knuff), gummiband, servoarm med en M3-skruv som knuff mot armens +y-sida. Servot är inte fäst i armen.

## Filer
- `cad_egen/provarm.py`: källa (build123d). Kör med `~/dev/rc-lankarm/.venv/bin/python`. Lokalt i `~/dev/lowrider/machine/delar/nollpunkt/`, ej committat.
- `cad_egen/provarm.3mf`: skivad, PETG, ca 1,6 h, 31 g. Utskrift via `~/dev/printa`.
- `cad_v1e/`: V1E:s Core, verktygsfäste och sko. Från Printables 1034840 och 1033926.
- `skanning/`: mesh (cm, Z upp) och `reference.json`, session FB60AE5F. Texturerna ligger kvar i `~/dev/worldforge/.worldforge/reconstruction/FB60AE5F-8FC7-4942-BF21-61C3BB430C1F/`.
- `skript/`: analyser. De läser `/tmp/nollpunkt-prov0` och kräver trimesh, scipy och rtree; sökvägarna behöver anpassas. `kontroll.py` är krockkontrollen.

## Att se upp med
Fusion-dokumentet med skanningen hette Untitled och var osparat. Maskinrörelser kräver alltid Adams ja via cnc-verktygen. Git: `/Library/Developer/CommandLineTools/usr/bin/git`.
