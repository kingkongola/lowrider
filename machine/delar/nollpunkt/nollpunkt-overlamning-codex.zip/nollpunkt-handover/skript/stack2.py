import numpy as np, trimesh, warnings, json
warnings.filterwarnings('ignore')
from scipy.spatial import cKDTree
d=np.load('mesh.npz');V,F,col=d['V'],d['F'],d['col']
fill=(np.abs(col-np.array([62,55,62])).sum(1)<30)
scan=trimesh.Trimesh(V,F[~fill],process=False)
sp,_=trimesh.sample.sample_surface(scan,600000,seed=1);tree=cKDTree(sp)
f=np.load('dust_shoe_makita_fit.npz');Rs,ts=f['R'],f['t']
core=trimesh.load('cad/Core.stl');P,_=trimesh.sample.sample_surface(core,20000,seed=2)
D='/Users/bemca/dev/lowrider/machine/delar/'
yaw=np.radians(22.172);cy,sy=np.cos(yaw),np.sin(yaw);Rw=np.array([[cy,-sy,0],[sy,cy,0],[0,0,1]])
def um(a,b):
    ma,mb=a.mean(0),b.mean(0);A,B=a-ma,b-mb
    U,S,Vt=np.linalg.svd(B.T@A/len(a));Dd=np.eye(3)
    if np.linalg.det(U)*np.linalg.det(Vt)<0:Dd[2,2]=-1
    R=U@Dd@Vt;return R,mb-R@ma
def toM(P,ys,zs): return np.c_[P[:,0]-193.7, zs*(P[:,2]-92.5), ys*(P[:,1]-169.17)+94.75]
res={}
for ys,zs in ((1,-1),(-1,1)):
    M=toM(P,ys,zs);Q=(M@Rs.T)+ts;dd,_=tree.query(Q)
    print('ys',ys,'zs',zs,'stack: in3',round((dd<3).mean(),3),'in5',round((dd<5).mean(),3),'med',round(np.median(dd),1),end=' | ')
    # lokal stel förfining, liten
    R,t=Rs,ts
    for i in range(25):
        Q=(M@R.T)+t;dd,ii=tree.query(Q);ok=dd<=np.quantile(dd,.5);R,t=um(M[ok],sp[ii[ok]])
    Q=(M@R.T)+t;dd,_=tree.query(Q)
    dR=np.degrees(np.arccos(np.clip((np.trace(R@Rs.T)-1)/2,-1,1)));print('förfinad in3',round((dd<3).mean(),3),'in5',round((dd<5).mean(),3),'med',round(np.median(dd),1),'flytt',np.round((t-ts),1),'vrid°',round(dR,1))
    res[(ys,zs)]=(R,t,M,dd)
# verktygsfästena mot skanningen med skon som ram (samma CAD-ram)
for n in ['tool-mount-t-v1-makita','tool-mount-b_makita','dust_shoe_makita']:
    m=trimesh.load(D+n+'.stl');Pm,_=trimesh.sample.sample_surface(m,8000,seed=3)
    dd,_=tree.query((Pm@Rs.T)+ts);print(n,'i skonramen: in3',round((dd<3).mean(),3),'med',round(np.median(dd),2))
print('Rs z-axel',(Rs@[0,0,1]).round(3),'axel vid z=0 rätad',(ts@Rw).round(1))
np.savez('stack.npz',Rs=Rs,ts=ts)
