import numpy as np, trimesh
from scipy.spatial import cKDTree
S=np.load('scan_M.npy');tree=cKDTree(S)
# okända klumpar vid plattan
for lab,m in (('klump z75-115',(S[:,2]>75)&(S[:,2]<115)&(S[:,0]>-16)&(S[:,0]<15)&(S[:,1]>36)&(S[:,1]<75)),('klump z55-75',(S[:,2]>55)&(S[:,2]<75)&(S[:,0]>-35)&(S[:,0]<15)&(S[:,1]>50)&(S[:,1]<75))):
    q=S[m];print(lab,len(q),q.min(0).round(1) if len(q) else '',q.max(0).round(1) if len(q) else '')
# arm: svängplan y=y0, pivot (xp,y0,zp), L, från ned (-z) till ut (+x)
core=trimesh.load('cad/Core.stl');C=core.vertices;Cm=np.c_[C[:,0]-193.7,C[:,2]-92.5,-(C[:,1]-169.17)+94.75]
tc=cKDTree(Cm)
def sweep(y0,xp,zp,L,hw=8,th=np.radians(np.arange(0,101,2.5))):
    # hw = armens halvbredd i y; tjocklek ±6 i planet
    pts=[]
    for a in th:
        d=np.array([np.sin(a),0,-np.cos(a)])
        for t in np.linspace(0,L,40):
            for dy in (-hw,0,hw):
                pts.append([xp+t*d[0],y0+dy,zp+t*d[2]])
    pts=np.array(pts)
    d,_=tree.query(pts);dc,_=tc.query(pts)
    i=d.argmin();return d.min().round(1),pts[i].round(0),dc.min().round(1)
nut=14.7;tip_long=nut-50
for zp,y0 in ((60,60),(60,62),(50,62),(70,60),(95,60)):
    L=zp-(tip_long-5)
    print('pivot z',zp,'y',y0,'L',round(L,1),'minsta avstånd skanning, punkt, Core:',sweep(y0,3.0,zp,L),'stuvad spets x',round(3+L,0))
# fristående tornet: hur långt från allt är stolpen vid olika z
for z0,z1 in ((-45,0),(0,31),(31,55),(55,115),(115,135)):
    x=np.linspace(-5,12,18);y=np.linspace(52,68,17);z=np.linspace(z0,z1,20);G=np.array(np.meshgrid(x,y,z)).reshape(3,-1).T
    print('zone',z0,z1,'min avst',tree.query(G)[0].min().round(1))
print('skanningens lägsta z nära fräsen', S[np.hypot(S[:,0],S[:,1])<40][:,2].min().round(1))
print('---slutlig')
for zp,y0 in ((32,62),(32,60),(36,62)):
    L=zp-(tip_long-5);print('pivot z',zp,'y',y0,'L',round(L,1),sweep(y0,3.0,zp,L),'stuvad spets x',round(3+L))
