import numpy as np, trimesh, warnings, sys
warnings.filterwarnings('ignore')
from scipy.spatial import cKDTree
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
N='/Users/bemca/dev/lowrider/machine/delar/nollpunkt/';D='/Users/bemca/dev/lowrider/machine/delar/'
f=trimesh.load(N+'provarm_faste.stl');a=trimesh.load(N+'provarm_arm.stl')
print('vattentät',f.is_watertight,a.is_watertight,'fäste',f.bounds.round(1).tolist(),'arm',a.bounds.round(1).tolist())
core=trimesh.load('/tmp/nollpunkt-prov0/cad/Core.stl')
Cv=core.vertices;core=trimesh.Trimesh(np.c_[Cv[:,0]-193.7,Cv[:,2]-92.5,-(Cv[:,1]-169.17)+94.75],core.faces,process=False)
if core.volume<0:core.invert()
omg={'Core':core}
for n,p in (('MountT','tool-mount-t-v1-makita'),('MountB','tool-mount-b_makita'),('Sko','dust_shoe_makita'),('Kjol','dust_skirt_makita')):omg[n]=trimesh.load(D+p+'.stl')
L=np.array([10.5,48,35.])
def rotx(deg):
    t=np.radians(deg);c,s=np.cos(t),np.sin(t);R=np.eye(4);R[1:3,1:3]=[[c,-s],[s,c]]
    return trimesh.transformations.translation_matrix(L)@R@trimesh.transformations.translation_matrix(-L)
# servo-dummy
serv=trimesh.creation.box(extents=[41,20,40]);serv.apply_translation([25+20.5,48,35+10])
hal=trimesh.creation.cylinder(radius=20,height=6);hal.apply_transform(trimesh.transformations.rotation_matrix(np.pi/2,[0,1,0]));hal.apply_translation([22,48,35])
S=np.load('/tmp/nollpunkt-prov0/scan_M.npy');Sc=S[(S[:,0]>-12)&(S[:,0]<70)&(S[:,1]>25)&(S[:,1]<85)&(S[:,2]>-30)&(S[:,2]<140)];ts=cKDTree(Sc)
def mindist(m,n=12000):
    p,_=trimesh.sample.sample_surface(m,n,seed=1)
    return p
res={}
kropp={'fäste':f,'servo':serv}
for kn,k in kropp.items():
    P=mindist(k)
    for n,m in omg.items():
        d=trimesh.proximity.ProximityQuery(m).signed_distance(P[:4000])
        print(kn,'mot',n,'intryck(+)/fritt(-) mm',round(float(d.max()),1))
    print(kn,'mot skanning min',round(float(ts.query(P)[0].min()),1))
print('arm i svep')
Pa,_=trimesh.sample.sample_surface(a,4000,seed=2)
out=[]
for deg in [0,45,90,135,150,155,158,160,162,165]:
    T=rotx(deg*1.0);Q=trimesh.transformations.transform_points(Pa,T)
    row=[deg]
    for n,m in list(omg.items())+[('fäste',f),('servo',serv)]:
        d=trimesh.proximity.ProximityQuery(m).signed_distance(Q)
        row.append(round(float(d.max()),1))
    row.append(round(float(ts.query(Q)[0].min()),1));row.append(np.round(Q.max(0)[1:],0).tolist());out.append(row)
    print(row)
print('kolumner: grader,',list(omg)+['fäste','servo','skanning','max y,z'])
