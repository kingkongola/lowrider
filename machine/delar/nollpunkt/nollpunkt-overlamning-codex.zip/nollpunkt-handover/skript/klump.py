import numpy as np, warnings
warnings.filterwarnings('ignore')
from PIL import Image, ImageDraw
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
d=np.load('mesh.npz');V,F,col,n=d['V'],d['F'],d['col'],d['n']
f=np.load('dust_shoe_makita_fit.npz');Rs,ts=f['R'],f['t'];Vm=(V-ts)@Rs;nm=n@Rs
xl=(15,95);yl=(25,145);Sc=12
T=Vm[F];keep=T[:,:,0].max(1)>-40   # bara ytor framför Core-ytan
idx=np.where(keep)[0];o=idx[np.argsort(T[idx].mean(1)[:,0])]
P=np.c_[(Vm[:,1]-xl[0])*Sc,(yl[1]-Vm[:,2])*Sc]
w,h=(xl[1]-xl[0])*Sc,(yl[1]-yl[0])*Sc
a=Image.new('RGB',(w,h),'white');b=Image.new('L',(w,h),255);da=ImageDraw.Draw(a);db=ImageDraw.Draw(b)
for i in o:
    p=P[F[i]]
    if p[:,0].max()<0 or p[:,0].min()>w or p[:,1].max()<0 or p[:,1].min()>h:continue
    pts=[tuple(x) for x in p];da.polygon(pts,fill=tuple(col[i].astype(int)));db.polygon(pts,fill=int(40+200*abs(nm[i,0])))
fig,ax=plt.subplots(1,2,figsize=(14,10.5))
for x,im,t,kw in ((ax[0],a,'Foto från skanningen',{}),(ax[1],b,'Bara formen (skuggad)',{'cmap':'gray','vmin':0,'vmax':255})):
    x.imshow(np.asarray(im),extent=[*xl,*yl],**kw);x.set_title(t);x.set_xlabel('y: längs balken (mm)');x.set_ylabel('z: uppåt (mm)');x.grid(alpha=.25)
    x.add_patch(Rectangle((36,75),38,40,fill=False,ec='cyan',lw=2,ls='--'))
    x.text(37,116,'"klumpen": området jag frågade om',color='cyan',fontsize=10,weight='bold',bbox=dict(fc='k',alpha=.6,pad=2))
    for y,z in ((43.95,64.25),(43.95,125.25)):
        x.plot(y,z,'x',c='lime',ms=11,mew=2.5)
    x.annotate('M5-skruv (CAD)',(43.95,125.25),(18,136),color='lime',weight='bold',arrowprops=dict(arrowstyle='->',color='lime'),bbox=dict(fc='k',alpha=.6,pad=2))
    x.annotate('M5-skruv (CAD)',(43.95,64.25),(18,48),color='lime',weight='bold',arrowprops=dict(arrowstyle='->',color='lime'),bbox=dict(fc='k',alpha=.6,pad=2))
    x.annotate('Cores ficka (CAD: y 57, z 65)',(57,65.25),(58,40),color='yellow',weight='bold',arrowprops=dict(arrowstyle='->',color='yellow'),bbox=dict(fc='k',alpha=.6,pad=2))
    x.annotate('röd kabel?',(47,104),(60,128),color='#ff8080',weight='bold',arrowprops=dict(arrowstyle='->',color='#ff8080'),bbox=dict(fc='k',alpha=.6,pad=2))
    x.axvline(73,c='orange',lw=1.5);x.text(73.5,30,'Core-änden y 73',color='orange',fontsize=9,weight='bold',bbox=dict(fc='k',alpha=.6,pad=2))
fig.tight_layout();fig.savefig('klump_annoterad.png',dpi=130)
