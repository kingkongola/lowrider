import numpy as np, trimesh
from PIL import Image, ImageDraw
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
S=np.load('scan_M.npy')
def band(m,ax):
    q=S[m,ax];return len(q),np.percentile(q,[10,50,90]).round(2) if len(q) else None
print('Core-yta (CAD -15):',band((S[:,1]>62)&(S[:,1]<72)&(S[:,2]>40)&(S[:,2]<52)&(S[:,0]>-22)&(S[:,0]<-8),0))
print('Core-yta y-50..-90 z55-75:',band((S[:,1]<-55)&(S[:,1]>-90)&(S[:,2]>55)&(S[:,2]<75)&(S[:,0]>-25)&(S[:,0]<-5),0))
print('Core +My-ände (CAD 73):',band((S[:,0]>-60)&(S[:,0]<-25)&(S[:,2]>38)&(S[:,2]<52)&(S[:,1]>62)&(S[:,1]<85),1))
print('Core-underkant (CAD 18.3):',band((S[:,0]>-110)&(S[:,0]<-60)&(np.abs(S[:,1])<60)&(S[:,2]>0)&(S[:,2]<40),2))
print('axelprofil: radie per höjd (mm)')
for z in range(-40,60,4):
    m=(np.abs(S[:,2]-z)<2)&(np.hypot(S[:,0],S[:,1])<30);q=S[m]
    if len(q)>20:
        c=q[:,:2].mean(0);r=np.hypot(*(q[:,:2]-c).T);print(z,len(q),'c',c.round(1),'r p50/p95',np.percentile(r,[50,95]).round(1))
    else:print(z,len(q))
d=np.load('mesh.npz');V,F,col=d['V'],d['F'],d['col']
f=np.load('dust_shoe_makita_fit.npz');Rs,ts=f['R'],f['t'];Vm=(V-ts)@Rs
def view(a,b,dp,sg,xl,yl,lab):
    Sc=5;w=int((xl[1]-xl[0])*Sc);h=int((yl[1]-yl[0])*Sc);im=Image.new('RGB',(w,h),(255,255,255));dr=ImageDraw.Draw(im)
    T=Vm[F];cz=T.mean(1)[:,dp];o=np.argsort(sg*cz)
    P=np.c_[(Vm[:,a]-xl[0])*Sc,(yl[1]-Vm[:,b])*Sc]
    for i in o:
        t=T[i];p=P[F[i]]
        if p[:,0].max()<0 or p[:,0].min()>w or p[:,1].max()<0 or p[:,1].min()>h:continue
        dr.polygon([tuple(x) for x in p],fill=tuple(col[i].astype(int)))
    return np.asarray(im)
xl=(-110,110);yl=(-90,150)
fig,ax=plt.subplots(1,2,figsize=(17,9.5))
ax[0].imshow(view(1,2,0,1,xl,yl,''),extent=[*xl,*yl]);ax[0].set_title('Mot Core-ytan (från +x): vänster/höger = y');ax[0].set_xlabel('y (mm)');ax[0].set_ylabel('z (mm)')
xl2=(-60,180);ax[1].imshow(view(0,2,1,-1,xl2,yl,''),extent=[*xl2,*yl]);ax[1].set_title('Från sidan (från +y)');ax[1].set_xlabel('x (mm)')
nut=14.7;tl=nut-50;ts_=nut-18
for a,xr in ((ax[0],(-110,110)),(ax[1],(-60,180))):
    for z,c,l in ((nut,'#0af','hylsmutter'),(tl,'r','längsta spets'),(tl-5,'m','probens läge'),(24,'g','kjol')):
        a.axhline(z,c=c,lw=1);a.text(xr[0]+2,z+1,f'{l} {z:.1f}',color=c,fontsize=8)
    a.grid(alpha=.3)
# arm
y0=62;xp=3;zp=50;L=zp-(tl-5)
ax[0].plot([y0,y0],[zp,tl-5],c='m',lw=4);ax[0].plot([y0],[zp],'o',c='m')
ax[1].plot([xp,xp],[zp,tl-5],c='m',lw=4);ax[1].plot([xp,xp+L],[zp,zp],c='m',lw=2,ls='--');ax[1].plot([xp],[zp],'o',c='m')
for y in (43.95,-43.95):
    for z in (64.25,125.25):ax[0].plot([y],[z],'x',c='lime',ms=9,mew=2)
fig.tight_layout();fig.savefig('layout_prov0.png',dpi=130)
