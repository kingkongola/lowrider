import numpy as np, trimesh, warnings
warnings.filterwarnings('ignore')
d=np.load('mesh.npz');V,F,col=d['V'],d['F'],d['col']
fill=(np.abs(col-np.array([62,55,62])).sum(1)<30)
scan=trimesh.Trimesh(V,F[~fill],process=False)
sp,_=trimesh.sample.sample_surface(scan,600000,seed=1)
f=np.load('dust_shoe_makita_fit.npz');Rs,ts=f['R'],f['t']
S=(sp-ts)@Rs      # skanning i fräsramen M
np.save('scan_M.npy',S)
# höjder i M (fräsaxel x=y=0, z upp), från CAD + M1
plate=31.0; nut=plate-16.3
print('hylsmutter underkant z',nut,'längsta spets (50)',nut-50,'kortaste (18)',nut-18,'kjol under',24.0)
core=trimesh.load('cad/Core.stl')
M=core.vertices.copy();C=np.c_[M[:,0]-193.7,M[:,2]-92.5,-(M[:,1]-169.17)+94.75]
print('Core i M: min',C.min(0).round(1),'max',C.max(0).round(1))
# kandidatkorridorer: stolpe vid (x0,y0), radie r; räkna skanningspunkter
def col_pts(x0,y0,r,z0,z1):
    m=(np.hypot(S[:,0]-x0,S[:,1]-y0)<r)&(S[:,2]>z0)&(S[:,2]<z1);return S[m]
for y0 in (55,60,65,70):
  for x0 in (-10,0,10,20):
    q=col_pts(x0,y0,8,nut-55,75)
    zs=(np.percentile(q[:,2],[0,100]).round(0).tolist() if len(q) else '')
    print('stolpe x',x0,'y',y0,'pkt',len(q),'z',zs)
# skanning: tvärsnitt i höjdskikt, vy ovanifrån
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
fig,ax=plt.subplots(2,3,figsize=(18,12))
for a,(z0,z1) in zip(ax.flat,[(-40,0),(0,20),(20,35),(35,55),(55,75),(75,115)]):
    m=(S[:,2]>z0)&(S[:,2]<z1);a.scatter(S[m,0],S[m,1],s=.2,c='k')
    # Core-kontur och skruvhål
    tri=C[core.faces];zc=tri[:,:,2].mean(1);k=(zc>z0)&(zc<z1);c=tri[k].reshape(-1,3);a.scatter(c[:,0],c[:,1],s=.2,c='#0a7')
    a.add_patch(plt.Circle((0,0),32.5,fill=False,color='b'));a.set_xlim(-120,120);a.set_ylim(-100,110);a.set_aspect('equal');a.grid(alpha=.4);a.set_xticks(range(-120,121,20));a.set_yticks(range(-100,111,20));a.tick_params(labelsize=6);a.set_title(f'z {z0}..{z1}: svart=skanning, grön=Core CAD, blå=Ø65');a.axhline(49.4,c='r',lw=.5);a.axvline(-15,c='r',lw=.5)
fig.tight_layout();fig.savefig('skikt_M.png',dpi=110)
