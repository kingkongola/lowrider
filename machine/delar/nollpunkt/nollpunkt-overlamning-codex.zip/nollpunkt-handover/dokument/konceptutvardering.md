# Automatisk nollpunkt LowRider V4 – konceptutvärdering

Nov 4, 2026 · @Adam

## Sammanfattning och rekommendation

**Läge (version 5, 2026-11-04): huvudspår B2, nu förenklad. Inte godkänd för detaljkonstruktion förrän geometrin är kontrollerad och prov 3 är gjort.**

Lasern utgick i version 4: Adam kräver att blank aluminium och genomskinlig akryl ska mätas, och det klarar ingen triangulerande laser i vår prisklass. (Specialoptik som klarar det finns, t.ex. konfokala givare, men den kostar många gånger budgeten.) En touchprob känner ytan mekaniskt och bryr sig inte om färg, glans eller genomskinlighet.

Tre ändringar i version 5, efter granskningen av version 4:

1. **Armen landar i ett kinematiskt säte** (tre kulor i tre spår) i stället för mot ett enkelt anslag. Då hamnar proben på samma ställe varje gång, och kalibrering i fyra riktningar varje cykel behövs inte. Varje cykel räcker en Z-beröring som kontroll. Om sätet håller måtten avgörs av prov 3.
2. **Säkerheten byggs som spärr, inte övervakning.** Servot är strömlöst utom under mätning, och fräsmotorn kan bara få ström när armen är uppe.
3. **Kullagret stryks.** Maskinen fräser i stället ett hål i referensklossen vid installationen. Hålet ligger då per definition där fräsen faktiskt skär.

**Beslutsregel:** Geometrikontrollen (prov 0) och prov 3 måste gå igenom innan detaljkonstruktion. Faller den egenbyggda proben i prov 5–6 byts den mot en köpt (ca 300–600 kr). Faller armen går vi till D (dockad probe).

**Varför jag växlade två gånger:** Jag valde vinnare innan de viktigaste egenskaperna var mätta. Version 1 valde laser på enkelhet, version 2 servo på pris. Båda gissade. Nu bestäms valet av mätvärden.

**Tillägg i uppdraget (Adam, 2026-11-04):** Minimera den totala merkostnaden genom att i första hand utnyttja befintliga resurser. Dyrare lösningar får endast rekommenderas om de ger en påvisbar och väsentlig förbättring av funktion, säkerhet eller tillförlitlighet.

## Behövs varje del? (version 5)

Genomgången stryker två saker (referensringen och kalibreringen varje cykel) och lägger till två små (servoströmbrytare och fräsrelä) som gör den farligaste felmoden omöjlig i stället för att bevaka den.

| Del | Funktion | Utan den | Beslut |
| --- | --- | --- | --- |
| Touchprob | mäter X, Y och Z på alla material | inget annat mäter blank metall och akryl | Behålls; egenbyggd eller köpt avgörs i prov 5 |
| Servo (ditt SPMS664) | fäller ned proben | proben måste sitta fast (krockar, se fakta 2) eller hämtas (D) | Behålls |
| Arm med led | bär proben | – | Behålls |
| Returfjäder | håller armen uppe utan servokraft | servot måste vara strömsatt under fräsning för att hålla armen | Behålls; det är den som låter servot vara strömlöst |
| Kinematiskt säte | proben hamnar på samma ställe | kalibrering i fyra riktningar varje cykel | **Nytt.** Samma delar som i proben: kulor och stift |
| "Arm uppe"-givare | bevisar att armen är uppe | ingenting vet det | Behålls; blir länk i spärren |
| Strömbrytare för servot (MOSFET, en transistor som slår av och på) | servot kan inte röra sig under fräsning | ryck vid uppstart eller glapp i signalen kan fälla armen | **Nytt**, ca 20 kr |
| Relä för fräsmotorn | fräsen får ström bara när armen är uppe | armen nere med snurrande fräs är möjligt | **Nytt** om du inte redan styr fräsen med relä |
| Verktygslängdsgivare | frässpetsens Z vid varje verktygsbyte | Z kan inte bestämmas | Behålls; din överblivna givare |
| Referensyta för Z | probens Z-offset | – | Ingen egen del: verktygslängdsgivarens hölje |
| Kullager som referensring | X/Y-kalibrering | – | **Struken.** Ersatt av ett hål maskinen fräser i klossen |
| Kalibrering i fyra riktningar varje cykel | tar bort fällningens spridning | – | **Struken** om prov 3 visar att sätet upprepar sig; görs då periodiskt |
| Kontroller (dubbelmätning, rimlighet) | stoppar en felaktig nolla | tyst fel | Behålls; kostar tid, inga delar |

### Felbudget: säte mot kalibrering varje cykel

Kravet är ± 0,10 mm per axel. Felkällorna är oberoende, så de läggs ihop som kvadratroten ur summan av kvadraterna (RSS). **Alla värden är antaganden** tills proven har gjorts.

| Felkälla (3σ, mm) | Enkelt anslag, ingen kalibrering | Enkelt anslag + kalibrering varje cykel | Kinematiskt säte + kontroll | Mäts i |
| --- | --- | --- | --- | --- |
| Maskinens upprepbarhet | 0,05 | 0,05 | 0,05 | prov 1 |
| Probens utlösning | 0,03 | 0,03 | 0,03 | prov 5 |
| Fällningens spridning | 0,10–0,30 (plastled med glapp, hävstång) | 0 (kalibreras bort) | 0,01–0,03 | prov 3 |
| Kalibreringens egen spridning | 0 | 0,03 | 0,03 (periodisk) | prov 6 |
| **Summa (RSS)** | **0,12–0,31, för mycket** | **0,07** | **0,07** |  |

Sätet ger samma felbudget som kalibrering varje cykel, men med en Z-beröring i stället för fem mätningar och utan extra programlogik. **Regel:** visar prov 3 att sätet sprider högst 0,03 mm (3σ) räcker periodisk kalibrering. Annars behålls kalibrering varje cykel.

### Säkerhetskedjan

Principen är att göra felet omöjligt, inte bara upptäckbart.

1. **Under fräsning finns ingen kraft som kan fälla armen.** Servot får ström bara under mätning, via en FluidNC-utgång som är av vid uppstart. Ryck vid uppstart eller omstart kan då inte röra armen. Fjäder och tyngdkraft håller den uppe.
2. **Fräsmotorn får ström bara när armen är uppe.** "Arm uppe"-givaren sitter i serie med reläets styrström. Är armen kvar nere startar fräsen inte, och skulle den falla stannar fräsen. Spärren fungerar även om FluidNC hänger sig och även om fräsen slås på för hand, eftersom den sitter i strömmen.
3. **`probe_hard_limit`** stoppar rörelsen om proben ändå rör något utanför en mätning.

Kvarvarande fall: fjädern går av *och* armen faller under fräsning. Då stannar fräsen men maskinen rör sig tills proben slår i och larmar; ett stillastående verktyg kan gå av. Det är ett materialfel, inte en farlig situation. **230 V-delen:** köp en färdig reläbox för styrspänning, eller låt en elektriker koppla reläet. Bygg inte egen nätspänningskoppling.

### Svar på granskningen av version 4

| # | Invändning | Stämmer? | Åtgärd |
| --- | --- | --- | --- |
| 1 | Dokumentet motsade sig om lasern | Ja | Rättat i alla kapitel. "Ingen laser" gäller vår prisklass; specialoptik finns men kostar för mycket |
| 2 | Övervakningen under fräsning har en lucka | Ja | Ersatt av spärr (ovan) |
| 3 | Kalibreringen är inte bevisad | Ja | Parametrarna är listade (kap. Kalibrering); sätet och kalibreringen bevisas i prov 3 och 6 |
| 4 | Maskinen kontrollerar sig själv | Ja | Prov 6 mäter nu också med skjutmått och mot en referens med kända mått |
| 5 | Ingen geometrikontroll | Ja, största hålet | Prov 0: layout med rörelseområden före prototyp. Kräver din maskins mått |
| 6 | Servot kan röra sig vid uppstart | Ja | Servot är strömlöst utom vid mätning |
| 7 | Överkonstruerat? | Delvis | Genomgången ovan: två saker strukna, felbudgeten avgör resten |

## Prov 0, pass 1: får B2 plats? (2026-11-04)

Delvis besvarat. Sett ovanifrån får proben plats, men höjdled och riktningen i maskinen kräver mått som inte finns i repot. Källor: V1E:s STL-filer för Makita-fästet och dammskon samt aktiv config, båda i `~/dev/lowrider`. Skript och bild: `lowrider-nollpunkt/prov0_layout.py` och `prov0_ovanifran.png` i projektmappen.

| # | Fråga | Resultat | Status |
| --- | --- | --- | --- |
| G1 | Var kan proben sitta utanför dammskon? | På sidan mitt emot slangporten (135–225° i V1E:s system), med kulan minst 46 mm från fräsens axel. Mot slangporten krävs 77–135 mm | kontrollerat (STL) |
| G2 | Krockar den med Z-vagnen eller balken? | Nej. Armen ligger inom Cores längd (y 54–70, Core slutar vid y 73), så den når aldrig något Core inte når först. Minst 23 mm fritt mot Core och skanningen i hela svepet | kontrollerat (CAD + skanning) |
| G3 | Hur långt måste armen fälla? | Provarm v0: armen ca 55 mm, svänger ca 153° runt servots axel. Led vid y 48, z 35. Nedfälld spets vid z −20,3, 5 mm under en fräs med 30 mm utstick. Uppfälld spets vid ca y 75, z 84, ca 2 mm utanför Core-änden. Servots vinkel är inte uppmätt | räknat (CAD + M1); bekräftas i prov 3 |
| G4 | Kantmätning utan att verktyget slår i skivan | Proben känner kanten strax under ovansidan; verktyget går fritt om proben når minst 2 mm under verktygsspetsen. Gäller alla fyra kanter | räknat |
| G5 | Räcker Z-vandringen? | Z går MPos −95 till +3. Med 3,175-fräsen låg offerskivan vid ca −75. Med 52 mm arm går det att nolla på skiva plus fastspänning upp till ca 57 mm (utstick ca 19 mm antaget). Maskinens egen gräns är ca 73 mm med kort fräs. En arm för 50 mm utstick hade bara gett ca 37 mm | räknat; utstick ej uppmätt |
| G6 | Förlorad yta | Inget för fräsning. För probning en remsa på ca 70 mm (62 mm förskjutning plus kulans frigång) längs Core-ändens motsatta sida. Referensklossen måste stå minst så långt in. Vilken maskinsida det blir återstår att bestämma | räknat |
| G7 | Stöder din FluidNC funktionerna? | Version 3.9.9; config har redan nyckeln `probe_hard_limit` (av). Proben sitter på gpio.36, `toolsetter_pin` är ledig, fyra digitala utgångar finns (gpio 26, 27, 0, 2) för servo och servoström | kontrollerat (config) |
| G8 | Fräsmotorns ström | Ingen spindelstyrning i config; fräsen slås på för hand bakom NVR-brytaren (DECISIONS D013). Spärreläet måste sitta efter NVR:en, i 230 V | kontrollerat; **elarbete av behörig** |
| G9 | Ledig ingång för "arm uppe" till FluidNC | Alla sex ingångar i config är upptagna. Spärren behöver ingen ingång, men en kontroll vid jobbstart gör det | **återstår: Jackpot3-pinnar** |

## Prov 0, pass 2: layout i CAD och skanning (2026-11-04)

**B2 får plats utan nya hål i Core.** Ett fäste delar de två M5-skruvarna som håller verktygsfästet på höger sida, och armen hänger 48 mm från fräsaxeln. CAD för provarm v0 ligger i machine/delar/nollpunkt. Allt är geometri; inget är byggt eller provat.

Höjder och lägen räknas från fräsaxeln: x pekar bort från Core, y längs balken och z uppåt. Noll är V1E:s CAD-origo.

| Mått | Värde | Källa |
| --- | --- | --- |
| Core-ytan | x = −15 | CAD: fästets anliggningsyta |
| Skruvarna | y = ±43,95; z = 64,25 och 125,25 | CAD: håldelning 87,9 × 61 mm i både Core och fäste |
| Core-änden, höger | y = 73 | CAD |
| Hylsmutterns underkant | z = 14,7 | M1 = 16,3 mm under dammskoplattan (z 31) |
| Armens led | x = 10,5, y = 48, z = 35 | Förslag |
| Probspets nedfälld | x = 10,5, y = 48, z = −20,3 | Förslag |
| Probspets uppfälld | x = 10,5, y = ca 75, z = ca 84 | Förslag |

**Kontroll mot skanningen.** Skalan stämmer inom ca 0,7 %: den skannade dammskon avviker median 1,5 mm från CAD. Core-änden mättes till y 73,75 (CAD 73,0) och Core-ytan till x −17 till −18 (CAD −15). Hylsmuttern syns börja vid z 14–16 (M1 ger 14,7). Skruvskallarna på höger sida och Cores ficka vid y 57, z 65 syns där CAD säger. Den automatiska inpassningen av hela Core gav bara 31 % träff, troligen eftersom skanningen inte ser Cores insida, så läget bygger på hålen.

**Osäkert.** Fräsaxeln kan ligga ca 6 mm fel i skanningen och dammskon ca 6° mot offerskivan. Därför är måtten mot skanningen grova, medan CAD-måtten gäller. Verkligt verktygsutstick är inte uppmätt. Kablarna vid y 45–50 är de förberedda kablarna till touchplattan (Adam 2026-11-04). De kan troligen användas till proben; anslutningen är inte kontrollerad.

**Mått som behövs (cirka 15 minuter med skjutmått):**

- **M1:** avstånd från hylsmutterns underkant till dammskons kjol (den styva kanten, inte borsten).
- **M2:** behövs inte som mätning. \`verktyg.json\` har skärlängder (17 mm för de raka fräsarna, 24 mm för kulfräsen) men inget utstick; alla nio jobb har \`utstick: null\`. Ändrat 2026-11-04: nollning kräver utstick högst 30 mm, vilket längsta KWB (53,6 mm) klarar med minst 24 mm i chucken. Verktygslängdsgivaren vägrar om fräsen sticker ut mer. Tidigare resonemang: utstick högst 50 mm under hylsmuttern. Resonemang (antaget, inte mätt): skaftet ska in så djupt det går utan att bottna, ca 20 mm i en Makita-hylsa. 3,175-fräsar med 17 mm skärlängd är normalt ca 38 mm långa och sticker då ut ca 18–20 mm; KWB:s 8 mm-fräsar antogs vara 50–70 mm, men Adam säger att de inte är längre än de andra; längderna saknas i verktyg.json. M1 (Adam 2026-11-04): hylsmutterns undersida ligger 16,3 mm under dammskoplattans undersida. Verktygslängdsgivaren mäter det verkliga utsticket vid varje byte, och mätningen vägrar om verktyget hänger lägre än proben.
- **M3 (fortfarande öppen, bara maskinriktning):** foto rakt ovanifrån på fräsen med dammsko, där balken och slangen syns, plus vilken riktning som är +X och +Y.
- **M4 (löst av skanning och CAD):** fritt utrymme på verktygsfästet på sidan bort från slangen, där armens led skulle sitta.

## Granskning 2026-11-04: vad som stämde

Adam lät ChatGPT granska version 2. Sju av åtta punkter stämde helt eller delvis. FluidNC-punkterna har jag kontrollerat i FluidNC:s källkod ([Probe.h](https://github.com/bdring/FluidNC/blob/main/FluidNC/src/Probe.h), [Probe.cpp](https://github.com/bdring/FluidNC/blob/main/FluidNC/src/Probe.cpp)).

| # | Invändning | Stämmer? | Åtgärd i version 3 |
| --- | --- | --- | --- |
| 1 | Fjädern kan inte vrida tillbaka ett strömlöst servo genom växellådan | Ja, troligen. Ett RC-servo med metallväxlar är trögt att vrida baklänges | Servot kopplas loss från armen (det trycker bara, är inte fäst). "Felsäker" ändrat till "felupptäckande" tills provet visar annat |
| 2 | En beröring ger bara Z, inte X och Y | Ja | Kalibrering i X, Y och Z definierad mot en referensring (kap. Kalibrering) |
| 3 | `check_mode_start` styr inte larm 4 | Ja, jag hade fel. Den styr bara läget efter probning i testläge ($C). Larm 4 kommer ändå, alltid | Rättat i kap. 5 |
| 3b | `pin` och `toolsetter_pin` är samma probe | Ja, källkoden säger `return _probePin.get() \|\| _toolsetterPin.get()` | Proceduren får aldrig förutsätta vilken givare som slog till; varje G38 körs bara där den andra givaren inte kan nås |
| 4 | Touchproben slår till olika beroende på riktning (pre-travel) | Ja, välkänt för trebensprober | Kanter mäts alltid från samma håll som kalibreringen, så felet blir samma i båda och tar ut sig |
| 5 | Provet mäter spridning, inte riktighet | Ja | Riktighetsprov mot en kant maskinen själv har fräst, i alla riktningar, plus uthållighetsprov |
| 6 | Vad händer om armen faller under fräsning? | Ja, hål i version 2 | FluidNC:s `probe_hard_limit` larmar och stoppar rörelsen om proben slår till under vanlig körning (finns i källkoden; din version måste kontrolleras) |
| 7 | FluidNC kan styra RC-servo | Ja, som motortyp `rc_servo` på en egen axel | Kvar att kontrollera: ledig utgång på din Jackpot |
| 8 | B2 har blivit komplex; en laser för ca 1 000 kr kan vara billigast totalt | Ja | Beslutsregeln ovan sätter C först om den klarar provet |

## Krav: vilka material (förslag, Adam beslutar)

Uppdraget säger "skivmaterial, exempelvis MDF och plywood", men maskinen tar även skum, plast och aluminium. Materialkravet avgör valet mellan laser och touchprob och måste därför bestämmas först. Jag föreslår tre nivåer i stället för "alla eller inga":

- **Måste mäta:** systemet ska ge rätt nolla inom kravet.
- **Får vägra, måste upptäcka:** systemet får säga "kan inte mäta, nolla manuellt", men får aldrig tyst ge en felaktig nolla. Det är poka-yoke-kravet: fel måste vara omöjliga att missa, inte omöjliga att uppstå.
- **Utanför:** maskinen ska inte bearbeta materialet alls (stål, sten, glas, kolfiber utan inkapsling).

| Ytklass | Exempel | Fysiken | Laser (triangulering) | Touchprob | Föreslagen nivå |
| --- | --- | --- | --- | --- | --- |
| Matt, ogenomskinlig, styv | MDF, plywood, massivträ, OSB, matt plast, HDPE | ljuset sprids åt alla håll (diffust), ytan ger inte efter | bra, färg och fibrer ger små fel | bra | Måste mäta, ± 0,10 mm |
| Mörk eller svart, matt | svart ABS, mörk MDF | lite ljus tillbaka | osäker, ofta sämre upprepbarhet | bra | Måste mäta |
| Blank, ogenomskinlig | melamin, blank folie, fräst aluminium | ljuset studsar som i en spegel, förbi mottagaren | osäker till dålig, beror på vinkeln | bra | Måste mäta, om du vill ha aluminium |
| Genomskinlig | akryl, polykarbonat | ljuset går igenom och studsar från undersidan eller offerskivan | dålig, ger fel höjd | bra | **Med skyddspapper kvar: måste mäta.** Utan: får vägra |
| Mjuk men styv nog att fräsa | XPS, EPS, PIR, modellskum | probe trycker in ytan; ljuset tränger in en bit i skummet | måttlig, troligen systematiskt fel | måttlig, intryckning | Måste mäta, men lägre krav: ± 0,3 mm |
| Eftergivande | mjuk EVA, gummi, skumgummi | ytan flyttar sig | dålig till måttlig | dålig | Får vägra |

Två saker som gör tabellen mindre svartvit:

1. **Touchproben är inte helt materialoberoende.** På skum trycker den in ytan, och tunna lösa delar kan flytta sig när den känner kanten från sidan. Den är däremot oberoende av färg, glans och genomskinlighet, vilket är lasern sämst på.
2. **Lasern kan fastna på kontrollerna i stället för att ge fel nolla.** Genom genomskinlig akryl ser den offerskivan, och då blir tjockleken nära noll. Det stoppas av rimlighetskontrollen (kap. 5, nr 5). Blank metall ger ofta ingen eller hoppande signal, och det stoppas av dubbelmätningen (nr 4). Det måste också provas: kontrollerna måste kunna fela.

**Risknivåerna är bedömningar från hur triangulering fungerar, inte mätningar** på den kinesiska givaren. Proven i kap. 6 körs därför på sex material: MDF, plywood, XPS, svart plast, genomskinlig akryl (med och utan skyddspapper) och aluminium (fräst och blank).

**Hur valet påverkar konceptet:** Kräver du att blank aluminium och akryl utan papper ska mätas, faller lasern i praktiken bort och B2 blir huvudspår. Räcker "måste upptäcka" för dem, lever båda finalisterna kvar till proven.

**Beslut (Adam, 2026-11-04):** Även blank aluminium och genomskinlig akryl måste mätas. Allt fräsbart material i tabellen ligger därmed på nivån "måste mäta", utom eftergivande material (mjuk EVA, gummi) som får vägra men måste upptäckas. Skum har lägre krav, ± 0,3 mm.

**Tunt material i X/Y (rättat efter Adams påpekande):** Proben mäter först offerskivan bredvid skivan och sedan ovansidan. Då är både golvet och tjockleken kända, och kulan kan köras precis ovanför offerskivan i stället för på "halva tjockleken". Med en kula på Ø 2 mm och 0,2 mm fri höjd rör kulan kantens sida ner till ca 1,2 mm tjocklek. Tunnare än så träffar kulan kantens övre hörn; felet blir då räknebart eftersom kulans höjd och tjockleken är mätta, men det måste provas. Den verkliga gränsen är styvhet, inte geometri: ark som böjer sig eller glider undan (folie, tunn plast) får vägra X/Y men måste säga till.

## Problemet från grunden

G54 är det koordinatsystem som jobbet körs i: "nollan" i arbetsstycket, uttryckt i maskinens egna koordinater. För att sätta den automatiskt måste maskinen veta fyra saker. Tre av dem får vi nästan gratis.

| Storhet | Vad det är | Hur den kan bli känd | Krävd noggrannhet |
| --- | --- | --- | --- |
| Maskinens nolla | Var maskinen är efter hemkörning (homing, körning mot ändlägesgivarna) | Finns redan: LowRider V4 hemkör Y med två givare, X och Z | Mekaniska givare brukar upprepa inom några hundradels mm (antaget, mäts i prov) |
| Verktygsspetsen | Hur långt fräsen sticker ut ur hylsan; ändras vid varje verktygsbyte | Fast verktygslängdsgivare (toolsetter): fräsen trycker på en fjädrande kolv med en brytare | 0,02–0,05 mm |
| Skivans ovansida (Z) | Var materialet börjar | Kan inte räknas fram: skivtjockleken varierar (vi har mätt 8,25–10,22 mm på en "9 mm"), och MDF-offerskivan sväller med fukt | 0,05–0,10 mm |
| Skivans hörn (X/Y) | Var materialet ligger | Mäts mot två kanter | 0,10 mm vid fräsning i färdig del; några mm vid utskärning ur skiva |

**Tre fysikaliska fakta styr konceptvalet:**

1. **Trä leder inte ström.** En vanlig probe fungerar genom att fräsen slutar en krets mot en metallplatta. På MDF och plywood finns ingen krets, därför behövs i dag en platta som läggs dit för hand. Det är just det momentet som ska bort.
2. **En fast probe som rör skivan går inte.** Sitter dess spets lägre än fräsen släpar den i arbetet. Sitter den högre når fräsen skivan först. Det låser alla kontaktprober till två vägar: något som fälls ut, eller något maskinen hämtar. En givare som inte rör skivan (ljus, kamera) slipper valet helt.
3. **Allt utanför verktyget måste kopplas till verktygsspetsen.** Var givaren sitter i förhållande till fräsen (offset) måste vara känt. Det görs bäst genom att maskinen själv mäter offseten mot något den själv har fräst, så att ingen mäter med skjutmått.

**Kan något elimineras?** Ja, delvis. Om skivan alltid skjuts in i ett fast hörnanslag behöver X/Y inte mätas alls (koncept A). Men kravet att skivan får ligga var som helst inom ett sökområde, och att Z måste mätas ändå, gör att anslaget inte räcker ensamt.

## Koncepten

Fem principiellt olika sätt, plus B2 som är B gjord felsäker. Alla utom A delar en fast **verktygslängdsgivare** i ett hörn av bordet, eftersom verktygslängden måste mätas vid varje verktygsbyte oavsett hur skivan mäts. Den gör dessutom dubbel tjänst: dess överdel är en fast referensyta som skivgivaren kan mäta mot för självtest.

### A. Fast hörnanslag (eliminera mätningen)

Två låga anslagslister (t.ex. 4 mm höga, lägre än tunnaste skivan) skruvas fast på offerskivan, frästa på plats av maskinen själv så de ligger exakt i maskinens koordinater. Skivan skjuts in i hörnet: X/Y känt. Z = offerskivans höjd plus angiven tjocklek. *Ingen givare alls.* Men: skivan måste ligga i hörnet, spån i hörnet ger tyst fel, och Z blir fel med tjockleksvariation och fukt.

### B. Servofälld kontaktprob (din SPMS664 + en mekanisk givare)

En arm med en mikrobrytare fälls ned av servot mot ett hårt anslag (anslaget bestämmer läget, servot bara trycker), probar ovansidan och fälls upp. Kanter hittas genom att proba Z i steg tvärs över kanten: där ytan "försvinner" ligger kanten. Billig och använder det du har. Men ny felmod: armen kvar nere vid fräsning. Det kräver en tredje givare som bekräftar "uppfälld", och servo, länkar och brytare sitter i dammet.

### B2. Servofälld touchprob, med felupptäckt (finalist)

Samma idé som B, men med tre tillägg som tar bort B:s svagheter utan att kosta något att tala om.

1. **En riktig touchprob i stället för en brytare.** En egenbyggd kinematisk probe: en pinne som vilar på tre stålkulor i tre par stift och hålls nere av en fjäder. Kulorna leder ström i serie; när pinnen rörs åt *något* håll lyfter en kula och kretsen bryts. Den känner alltså även kanter från sidan. Kinematisk betyder att delen bara kan ligga på ett enda sätt (sex kontaktpunkter, sex frihetsgrader). Känd svaghet: den slår till efter olika lång väg beroende på riktning (pre-travel). Hanteras genom att kanter alltid mäts från samma håll som vid kalibreringen. Delar ca 100–200 kr.
2. **Fjäderretur med löst servo.** En fjäder drar armen upp. Servot är inte fäst i armen, det trycker bara ned den i ett kinematiskt säte (version 5). När servot går till "upp" följer armen fjädern oberoende av servot. Kvarstående fall: servot dör i nedläge och håller kvar armen. Då måste fjädern vrida servot baklänges, och det är **inte visat** att den klarar det. Därför kallas konstruktionen *felupptäckande*, inte felsäker, tills prov visar annat.
3. **Spärr i stället för övervakning (version 5, se Säkerhetskedjan).** Före jobbstart: en överbliven ändlägesgivare måste visa "arm uppe". Under fräsning: om armen ändå faller slår proben i arbetsstycket, och FluidNC:s `probe_hard_limit` larmar och stoppar rörelsen. Styrs fräsmotorn för hand stannar den inte; fräsen står då still och snurrar.
4. **Kalibrering, periodisk om sätet håller (version 5),** mot den gemensamma referensklossen, se kap. Kalibrering. Felbudgeten i kap. "Behövs varje del?" avgör hur ofta.

Kvar som risk: dammet i armens led och servot, och hur väl den egenbyggda proben upprepar sig. Båda mäts i kap. 6.

### C. Fast laseravståndsgivare (utgår: klarar inte blank metall och genomskinligt, Adams materialkrav 2026-11-04)

En laseravståndsgivare med triangulering (en laserprick, en kamera i vinkel; där pricken syns ger avståndet) sitter fast bredvid fräsen, tittar ned, högre än frässpetsen. Exempel: Panasonic HG-C1030, mätområde 30 ± 5 mm, upprepbarhet 10 µm på tillverkarens referensyta, prick ø 0,05 mm, IP67, 12–24 V, med en inbyggd **koppla-vid-avstånd-utgång** ([datablad](https://www.mouser.com/datasheet/2/315/hg_c_hg_c1000l_e_cata-3195293.pdf)).

Poängen: utgången beter sig som en vanlig probe. FluidNC:s probkommando (G38.2: "kör tills proben slår till, spara läget") fungerar oförändrat.

1. **Z:** sänk Z tills utgången slår om. Ovansidan ligger nu exakt på givarens tröskelavstånd.
2. **X och Y:** stanna på den höjden och kör ut över kanten. Offerskivan ligger minst 3 mm lägre, så utgången slår av exakt vid kanten (G38.4: "kör tills proben släpper").

En enda tröskel, inställd en gång, räcker för alla tjocklekar eftersom Z-axeln flyttar givaren dit. Ingen rörlig del, inget som fälls ut, ingen hand. Osäkert: hur träets färg, fibrer och kantflisor påverkar, samt damm på fönstret.

**Billiga alternativ.** Kinesiska givare i samma format finns hos t.ex. Fuwei (FSD22-serien), Nanneng och Songger, ofta med datablad som är kopierade ord för ord från Panasonic ([exempel](https://rcdrone.top/products/hg-c1030-laser-distance-sensor-displacement-measurement-analog-output-thickness-sensor-pnp-npn-industrial-automation-precision), [FSD22-blad](https://schwa.dyyweb.com/fsd22-series-high-precision-laser-displacement-sensor)). Jag kunde inte läsa AliExpress-sidorna härifrån, så priserna är overifierade. Ett kopierat datablad bevisar ingenting om den faktiska givaren; därför måste den mätas.

Vad som duger och inte:

- **Duger på papperet:** modeller med 30 mm mätavstånd ("-30"), som anger ca 10 µm upprepbarhet och har en kopplande utgång (NPN eller PNP).
- **Duger inte:** 100 mm-modellerna (anger 100 µm, alltså hela felbudgeten i en enda givare) och de små ljuspulsmodulerna (time-of-flight, t.ex. VL53L0X, som bara mäter på några millimeter när, alltså 30–100 gånger för grovt).

### D. Magnetdockad touchprob (maskinen hämtar den)

En vanlig 3D-touchprob (en pinne som slår till åt alla håll) står i en docka vid bordskanten. Maskinen kör dit, en magnet med kinematisk koppling (tre kulor i tre spår, som alltid hamnar på samma ställe inom några µm) hämtar den, mäter, lämnar tillbaka. Samma princip som "Klicky"-prober på 3D-skrivare. Ingen aktuator och riktig kontakt mot kanten. Men: mer mekanisk konstruktion, kollisionsrisk vid hämtning, och den måste kunna bevisa att den är **tillbakalämnad** (krets genom magneterna).

### E. Kamera (maskinseende)

Kamera på Z-vagnen ser skivans hörn; en laserlinje i vinkel ger höjden. Snabbt och mäter vinkeln på skivan. Men kräver en dator med bildbehandling mellan kamera och FluidNC, är känslig för ljus, och det mesta av svårigheten flyttas till programvara som ska underhållas i åratal.

## Kalibrering av X, Y och Z (version 5)

Fyra saker måste vara kända för att probens mätning ska bli en nolla för fräsen:

1. Probkulans **effektiva radie i varje riktning** (+X, −X, +Y, −Y). Den innehåller både kulans radie och den väg proben rör sig innan den slår till.
2. Probens **X/Y-offset mot fräsens verkliga centrum**, alltså där fräsen faktiskt skär, inklusive kast (att verktyget vickar lite när det snurrar).
3. Probens **Z-offset mot frässpetsen**.
4. **Referensklossens läge** i maskinens koordinater.

Referensklossen sitter vid bordets hörn: verktygslängdsgivaren, en plan överdel och ett hål som maskinen själv fräser.

**Full kalibrering** (vid installation, och sedan periodiskt eller efter en krock):

1. Maskinen fräser ett hål (t.ex. Ø 20 mm) i klossen med ett uppmätt verktyg. Hålets centrum är därmed fräsens verkliga centrum.
2. Du mäter hålets diameter med skjutmått. Det är en oberoende mätning.
3. Proben känner hålet från fyra håll: centrum ger X/Y-offset, och den kända diametern ger effektiv radie per riktning.
4. Fräsen på verktygslängdsgivaren och proben på överdelen ger Z-offset.

**Varje cykel:** verktygslängd (om verktyget bytts) och en Z-beröring på överdelen som kontroll. Avvikelse över 0,03 mm = stopp och full kalibrering.

Kanter mäts alltid i samma riktningar som i hålet. Att känna hålets högra vägg (rörelse +X) motsvarar att känna en skivas vänstra kant (rörelse +X), så riktningsfelet blir detsamma och tar ut sig. **Kvar att visa:** att sätet upprepar sig (prov 3), och att effektiv radie mot klossens hål stämmer mot kanter i trä, akryl och aluminium (prov 6).

## Jämförelse mot kriterierna

Tabellen är från version 2–3 och visar varför B2 blev huvudspår. C ströks i version 4 på materialkravet, inte på tabellen. Betyg 1–5 (5 bäst) är mina bedömningar, inte mätningar.

| Kriterium | A Anslag | B Servoprob | B2 Felsäker servoprob | C Laser | D Dockad prob | E Kamera |
| --- | --- | --- | --- | --- | --- | --- |
| **Merkostnad utöver det du har** | ca 50 kr | ca 100 kr | ca 100–200 kr | ca 300–1 000 kr kinesisk kopia, 1 500–3 000 kr original (kopiornas priser ej verifierade) | ca 200–400 kr | 500–1 500 kr + dator |
| Automatisk X/Y/Z utan handgrepp | 2 (Z gissas, skivan måste i hörnet) | 5 | 5 | 5 | 5 | 5 |
| Fritt sökområde | 1 | 4 | 5 | 5 | 5 | 5 |
| Precision Z, trolig | 2 (tjocklek och fukt) | 3 (fällningens glapp) | 4 (glappet kalibreras bort) | 4 (måste provas på trä) | 4 | 3 |
| Precision X/Y, trolig | 3 (spån i hörnet) | 3 (stegvis probning) | 4 (känner kanten från sidan) | 4 (kantflisor, måste provas) | 4 | 3 |
| Rörliga delar i dammet | 0 | servo, arm, brytare | servo, arm, probe | 0 | docka, magnet, probe | 0 |
| Farlig felmod | spån i hörnet ger tyst fel | arm kvar nere vid fräsning | samma, men fjädern drar upp och givaren spärrar start | smutsigt fönster (upptäcks av självtest) | prob kvar på vagnen | fel bildtolkning |
| Livslängd 10 000 cykler | 5 | 3 | 4 (servo med metallväxlar, låg last) | 5 | 4 | 4 |
| Underhåll | sopa hörnet | rengöring, kontroll av arm | blåsa rent leden ibland | torka fönstret ibland | rengöra kontakter | lins, programvara |
| Förlorat arbetsområde | listerna | inget | inget | inget | dockan | inget |
| Tillverkning hemma | 5 | 4 | 4 | 5 | 3 | 4 |
| Programvara | ingen | enkel | enkel | enkel | medel | tung |

**C mot B2 i delar (historik):** C hade färre delar och ingen slitdel, men klarar inte blank metall och genomskinligt material. B2 har fler delar; vilka som verkligen behövs står i kap. "Behövs varje del?".

**Varför inte D som finalist:** D använder samma typ av probe som B2 men byter servot mot en docka som maskinen måste träffa exakt, och saknar returfjäder om proben blir kvar på vagnen. Den är reserv om båda finalisterna faller, då med en köpt probe.

## Felupptäckt och säkerhet

Principen är att G54 bara skrivs när alla kontroller har gått igenom, i ett enda sista steg. Ett avbrott halvvägs lämnar den gamla nollan orörd, så ingen kan av misstag köra på en halvmätt nolla. Kontrollerna gäller B2; de flesta gäller även C och D. Viktigast för B2 är nr 9: proben får aldrig vara nere när fräsen arbetar.

| # | Kontroll | Fångar | Hur |
| --- | --- | --- | --- |
| 1 | Givaren får inte vara utlöst vid start | kabelbrott, felinställd tröskel, något under givaren | FluidNC larm 4 (inbyggt, `alltid aktivt; inställningen check_mode_start påverkar bara testläget $C`) |
| 2 | Givaren måste slå till inom söksträckan | ingen skiva, död givare | FluidNC larm 5 (inbyggt) |
| 3 | Självtest mot fast referensyta före varje mätning | probens nya läge efter fällning, smuts, drift | mät verktygslängdsgivarens överdel; avvikelse > 0,05 mm från känt värde = stopp |
| 4 | Varje punkt mäts två gånger | vibration, spån, enstaka felmätning | skillnad > 0,03 mm = stopp |
| 5 | Tjockleken måste vara rimlig | fel skiva, givaren såg offerskivan | ovansida minus offerskiva inom angiven tjocklek ± 1 mm |
| 6 | Varje kant mäts i två punkter | skev skiva, kantflisa, spån mot kanten | vinkel > 0,2° eller punkterna oense = stopp med besked |
| 7 | Verktygslängden måste vara rimlig och upprepas | verktyg som glidit i hylsan, spån på givaren | två beröringar, skillnad > 0,02 mm = stopp |
| 8 | Fräsmotorn måste stå still vid verktygslängdsmätning | roterande fräs mot givaren | beror på om din Makita styrs av Jackpot (relä) eller slås på för hand; **okänt, måste kontrolleras** |

Larm 4 och 5 finns redan i FluidNC ([probdokumentation](https://dcmpx.remotevs.com/com/fluidnc/wiki/PL/en/config/probe)). Kontroll 3–7 kräver att något räknar och jämför. Antingen ett makro i FluidNC, om dess villkorssatser räcker (**inte verifierat**), eller ditt `cnc`-verktyg på datorn. Programvaran ingår inte i uppdraget; gränssnittet beskrivs i detaljfasen.

Lasern är klass 2 (1 mW): ofarlig vid kort oavsiktlig blick, men titta inte in i strålen.

## Osäkerheter, saknade mått och prov före detaljkonstruktion

Inget av precisionsvärdena ovan är verifierat. Tre saker kan bara mätas, inte räknas fram, och de avgör om C håller. Jag föreslår att vi mäter dem först, så att detaljkonstruktionen bygger på mätvärden.

### Föreslagna prov (i ordning, billigast först)

0. **Geometrikontroll (vid datorn, 0 kr).** En enkel layout av Z-vagnen, fräsmotorn, eventuell dammsko, armen i uppläge och nedläge, och referensklossen, med Z-vandringen. Kollas för kortaste och längsta verktyg och tunnaste och tjockaste skiva: når proben ytan och kanterna från alla fyra håll utan att fräsen kolliderar, går armen att fälla undan, nås klossen? Kräver din maskins mått. Görs före prototypen.
1. **Maskinens egen upprepbarhet (0 kr).** Hemkör 10 gånger och mät samma punkt med mätklocka eller din nuvarande probplatta. Struket 2026-11-04: varken mätklocka eller touchplatta finns, och nollan mäts om för varje jobb utan ny homing, så homingens spridning påverkar inte fräsningen. Maskinens spridning syns ändå i prov 5.
2. **Överblivna ändlägesgivare som verktygslängdsgivare (0 kr).** 50 tryck. Spridning under 0,02 mm: använd dem. Annars köps en färdig (ca 200–500 kr).
3. **Servoarmen (0 kr, printad provarm med säte och fjäder).**
   1. 200 fällningar, läget mätt mot en fast yta i X, Y och Z. Ger sätets spridning, som avgör periodisk kalibrering eller kalibrering varje cykel.
   2. Strömavbrott i nedläge, 20 gånger: går armen upp av fjädern?
   3. Avbruten körning: nödstopp och omstart av Jackpot mitt i en mätning, 10 gånger. Armen ska vara uppe efter omstart, och servot får inte röra sig vid uppstart.
   4. Spärren: med armen nere ska fräsen inte gå att starta, varken från FluidNC eller för hand. 10 gånger.
   5. Livslängd: 10 000 fällningar i automatisk körning (ca 6 timmar med 2 sekunder per fällning), med MDF-damm påstrött och spridningen mätt var 1 000:e. Det här provar hela målet på 10 000 cykler, inte bara en indikation.
4. **Hela systemet.** Proven 5–7 görs med proben på armen, monterad som den ska sitta.
5. **Spridning:** 30 Z-mätningar och 30 kantmätningar per riktning på sex material: MDF, plywood, XPS, svart plast, akryl (med och utan skyddspapper) och aluminium (fräst och blank). Krav: standardavvikelse under 0,02 mm (skum: 0,1 mm).
6. **Riktighet, oberoende kontrollerad.** Maskinen fräser en rektangel. Proben mäter den, och du mäter samma rektangel med skjutmått. Dessutom mäter proben en referens med kända mått som maskinen inte har gjort (t.ex. ett slipat 1-2-3-block eller ett kullagers ytterring, Ø 47 mm för 6005). Då syns fel som maskinen annars delar med sig själv, t.ex. fel steg per mm. Krav: kanter inom ± 0,10 mm, Z inom ± 0,05 mm.
7. **Proben i 10 000 cykler.** 10 000 utlösningar i automatisk körning (ca 8 timmar), med självtestet var 1 000:e. Krav: inga missade eller falska utlösningar.

**Ordning och kostnad:** Prov 0–2 kostar inget och görs först. Faller prov 0 eller 1 pratar vi om konstruktionen eller kraven innan något byggs. Sedan provarmen (prov 3) och touchproben (ca 150 kr), och sist prov 4–7.

### Saknade mått och fakta

De flesta finns troligen i din `~/dev/lowrider` (maskinens mått och config). Jag behöver läsa den mappen innan detaljkonstruktionen.

- [ ] Fräsmotorns modell och fäste, samt fritt utrymme runt Z-vagnen (givaren behöver ca 30 mm arbetsavstånd nedåt)
- [ ] Bordets och offerskivans mått, och var maskinen hemkör
- [ ] Lediga ingångar och utgångar på Jackpot 3 (proben, "arm uppe"-givaren, verktygslängdsgivaren, servosignalen). FluidNC kan styra RC-servot som motortypen rc\_servo (PWM, pulsbreddsmodulering: signalen ett RC-servo förstår). Kvar att se: ledig utgång, och om din FluidNC-version har probe\_hard\_limit. Kontrolleras i din config.
- [ ] Styrs fräsmotorn av Jackpot (relä) eller slås den på för hand?
- [ ] Finns dammsko eller sugkupa runt fräsen i dag?
- [ ] Vilken FluidNC-version kör du (avgör om kontrollerna kan ligga i makron)?
- [ ] Vilken noggrannhet behöver du verkligen i X/Y: fräser du i färdiga delar, eller skär du mest ut delar ur skivor?

## Källor

- [V1 Engineering: LowRider-dokumentation](https://docs.v1e.com/lowrider/) (hemkörning, ändlägesgivare, Z-vandring ca 50 mm)
- [FluidNC: probkonfiguration](https://dcmpx.remotevs.com/com/fluidnc/wiki/PL/en/config/probe) (`pin`, `toolsetter_pin`, larm 4 och 5)
- [Panasonic HG-C: datablad](https://www.mouser.com/datasheet/2/315/hg_c_hg_c1000l_e_cata-3195293.pdf) (HG-C1030)

* [FluidNC Probe.h](https://github.com/bdring/FluidNC/blob/main/FluidNC/src/Probe.h) och [Probe.cpp](https://github.com/bdring/FluidNC/blob/main/FluidNC/src/Probe.cpp) (check\_mode\_start, toolsetter\_pin, probe\_hard\_limit; läst 2026-11-04)
* KJT KELR-TE03: pris och data från ChatGPT:s sökning, inte öppnat av mig ([annons](https://www.alibaba.com/product-detail/Factory-Direct-Mini-HG-C1030-MOS_1601723774463.html))
